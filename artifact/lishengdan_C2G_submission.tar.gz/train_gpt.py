"""
lishengdan_C2G_train_gpt.py
===========================

C2G / Parameter Golf - final submission trainer.

Lineage (see `lishengdan_C2G_拿来说明.md` for the full attribution table):
  * scaffold, Muon, tokenizer-agnostic BPB, int8+zlib roundtrip export
        -> OpenAI Parameter Golf `train_gpt.py` (which itself adapts Keller Jordan's modded-nanogpt)
  * QK-gain, RMSNorm-on-QK, U-Net skip gating, resid_mix, zero-init projections
        -> modded-nanogpt line (Keller Jordan / leloykun)
  * SP8192 tokenizer + GPTQ/SDClip quantization + depth recurrence + parallel residuals
        -> leaderboard lineage: clarkkev (PR #1394), dexhunter (PR #1331/#1437/#1413),
           Robby955 (PR #1412), msisovic (PR #1204), abaybektursun (PR #549)
  * QA-EMA (quantization-aware weight averaging) and warmdown-aligned QAT onset
        -> original contribution of this submission (see technical report, Sec. 3.4)

Everything is env-var driven so that *the same file* runs the baseline, every
ablation arm, and the final configuration. This is deliberate: a submission whose
ablations are produced by different code paths is not evidence.

Device-agnostic: runs on CPU for local screening, and on CUDA for the official
8xH100 configuration. The CPU path exists so that the ablation matrix can be
screened for free before spending GPU budget.

Quick start (local screening):
    python lishengdan_C2G_train_gpt.py
Quick start (official configuration) is documented in `lishengdan_C2G_README.md`.
"""
from __future__ import annotations

import copy
import glob
import io
import json
import math
import os
import random
import subprocess
import sys
import time
import uuid
import zlib
from pathlib import Path

import numpy as np
import sentencepiece as spm
import torch
import torch.distributed as dist
import torch.nn.functional as F
from torch import Tensor, nn
from torch.nn.parallel import DistributedDataParallel as DDP

try:  # optional, only used for the brotli artifact
    import brotli
except ImportError:  # pragma: no cover
    brotli = None


# ----------------------------------------------------------------------------------
# HYPERPARAMETERS
# ----------------------------------------------------------------------------------

def _env(name: str, default):
    v = os.environ.get(name)
    return default if v is None or v == "" else v


class Hyperparameters:
    # --- data ---------------------------------------------------------------------
    data_path = _env("DATA_PATH", "./data/datasets/proxy_sp1024")
    train_files = os.path.join(data_path, "fineweb_train_*.bin")
    val_files = os.path.join(data_path, "fineweb_val_*.bin")
    tokenizer_path = _env("TOKENIZER_PATH", "./data/tokenizers/fineweb_1024_bpe.model")
    run_id = _env("RUN_ID", str(uuid.uuid4()))
    seed = int(_env("SEED", 1337))
    out_dir = _env("OUT_DIR", ".")
    result_json = _env("RESULT_JSON", "")

    # --- validation ---------------------------------------------------------------
    val_batch_size = int(_env("VAL_BATCH_SIZE", 262_144))
    val_loss_every = int(_env("VAL_LOSS_EVERY", 0))
    train_log_every = int(_env("TRAIN_LOG_EVERY", 100))

    # --- schedule -----------------------------------------------------------------
    iterations = int(_env("ITERATIONS", 20000))
    warmdown_iters = int(_env("WARMDOWN_ITERS", 1200))
    warmdown_frac = float(_env("WARMDOWN_FRAC", 0.0))  # if >0 overrides WARMDOWN_ITERS
    warmup_steps = int(_env("WARMUP_STEPS", 0))
    train_batch_tokens = int(_env("TRAIN_BATCH_TOKENS", 524_288))
    train_seq_len = int(_env("TRAIN_SEQ_LEN", 1024))
    max_wallclock_seconds = float(_env("MAX_WALLCLOCK_SECONDS", 600.0))
    qk_gain_init = float(_env("QK_GAIN_INIT", 1.5))

    # --- model shape --------------------------------------------------------------
    vocab_size = int(_env("VOCAB_SIZE", 1024))
    num_layers = int(_env("NUM_LAYERS", 9))
    num_kv_heads = int(_env("NUM_KV_HEADS", 4))
    model_dim = int(_env("MODEL_DIM", 512))
    num_heads = int(_env("NUM_HEADS", 8))
    mlp_mult = int(_env("MLP_MULT", 2))
    tie_embeddings = bool(int(_env("TIE_EMBEDDINGS", "1")))
    rope_base = float(_env("ROPE_BASE", 10000.0))
    logit_softcap = float(_env("LOGIT_SOFTCAP", 30.0))

    # --- [component] parallel residuals (GPT-J style) ------------------------------
    # Blocks at schedule position >= PARALLEL_RESID_FROM read attention and MLP from
    # the same pre-residual input instead of chaining them. -1 disables.
    parallel_resid_from = int(_env("PARALLEL_RESID_FROM", -1))

    # --- [component] depth recurrence ---------------------------------------------
    # Explicit execution schedule of *physical* layer indices. Repeating indices in
    # the second half of the list loops those blocks. Empty -> identity schedule.
    layer_schedule = _env("LAYER_SCHEDULE", "")

    # --- [component] weight averaging ---------------------------------------------
    ema_decay = float(_env("EMA_DECAY", 0.0))          # 0 disables EMA
    ema_every = int(_env("EMA_EVERY", 1))
    ema_start_frac = float(_env("EMA_START_FRAC", -1.0))  # <0 -> start at warmdown
    ema_quant_aware = bool(int(_env("EMA_QUANT_AWARE", "0")))  # QA-EMA (ours)

    # --- [component] quantization-aware training ----------------------------------
    qat_bits = int(_env("QAT_BITS", 6))
    qat_start_frac = float(_env("QAT_START_FRAC", 0.0))  # 0 disables QAT
    qat_embed_bits = int(_env("QAT_EMBED_BITS", 8))

    # --- export quantization ------------------------------------------------------
    # `quant_method` selects the ALGORITHM only: "rtn" (round-to-nearest) or "gptq"
    # (sequential Hessian-guided with error feedback). It does NOT select the clip rule.
    # The clip rule is `quant_clip`, independently.
    # "rtn_sdclip" is a LEGACY alias for "rtn": its name mentions SDClip but the code
    # never let it enable SDClip (see `symmetric_clip`), so the two were functionally
    # identical. It is accepted for backwards compatibility with archived runs and
    # normalised to "rtn" at startup, with a warning.
    quant_method = _env("QUANT_METHOD", "rtn")  # rtn | gptq   (legacy alias: rtn_sdclip)
    quant_bits = int(_env("QUANT_BITS", 6))
    quant_embed_bits = int(_env("QUANT_EMBED_BITS", 8))
    # "percentile" reproduces the scaffold's int8 clip rule (per-row quantile of |W|);
    # "sdclip" is this submission's rule, clip = k * std(row).
    quant_clip = _env("QUANT_CLIP", "percentile")
    sdclip_k = float(_env("SDCLIP_K", 12.85))
    clip_percentile = float(_env("CLIP_PERCENTILE", 99.99984))
    gptq_calib_batches = int(_env("GPTQ_CALIB_BATCHES", 8))
    compress = _env("COMPRESS", "zlib")               # zlib | brotli

    # --- optimizer ----------------------------------------------------------------
    embed_lr = float(_env("EMBED_LR", 0.6))
    head_lr = float(_env("HEAD_LR", 0.008))
    tied_embed_lr = float(_env("TIED_EMBED_LR", 0.05))
    tied_embed_init_std = float(_env("TIED_EMBED_INIT_STD", 0.005))
    matrix_lr = float(_env("MATRIX_LR", 0.04))
    scalar_lr = float(_env("SCALAR_LR", 0.04))
    weight_decay = float(_env("WEIGHT_DECAY", 0.0))
    muon_momentum = float(_env("MUON_MOMENTUM", 0.95))
    muon_backend_steps = int(_env("MUON_BACKEND_STEPS", 5))
    muon_momentum_warmup_start = float(_env("MUON_MOMENTUM_WARMUP_START", 0.85))
    muon_momentum_warmup_steps = int(_env("MUON_MOMENTUM_WARMUP_STEPS", 500))
    beta1 = float(_env("BETA1", 0.9))
    beta2 = float(_env("BETA2", 0.95))
    adam_eps = float(_env("ADAM_EPS", 1e-8))
    grad_clip_norm = float(_env("GRAD_CLIP_NORM", 0.0))

    # --- runtime ------------------------------------------------------------------
    compile_model = bool(int(_env("COMPILE", "1")))
    device_pref = _env("DEVICE", "auto")  # auto | cuda | cpu
    threads = int(_env("TORCH_THREADS", 0))


# ----------------------------------------------------------------------------------
# MUON OPTIMIZER  (borrowed from modded-nanogpt / OpenAI scaffold)
# https://kellerjordan.github.io/posts/muon/
# ----------------------------------------------------------------------------------

_MUON_DTYPE = torch.bfloat16


def zeropower_via_newtonschulz5(G: Tensor, steps: int = 10, eps: float = 1e-7) -> Tensor:
    a, b, c = (3.4445, -4.7750, 2.0315)
    X = G.to(_MUON_DTYPE)
    X /= X.norm() + eps
    transposed = G.size(0) > G.size(1)
    if transposed:
        X = X.T
    for _ in range(steps):
        A = X @ X.T
        B = b * A + c * A @ A
        X = a * X + B @ X
    return X.T if transposed else X


class Muon(torch.optim.Optimizer):
    def __init__(self, params, lr: float, momentum: float, backend_steps: int,
                 nesterov: bool = True, weight_decay: float = 0.0):
        super().__init__(params, dict(lr=lr, momentum=momentum, backend_steps=backend_steps,
                                      nesterov=nesterov, weight_decay=weight_decay))

    @torch.no_grad()
    def step(self, closure=None):
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        distributed = dist.is_available() and dist.is_initialized()
        world_size = dist.get_world_size() if distributed else 1
        rank = dist.get_rank() if distributed else 0

        for group in self.param_groups:
            params = group["params"]
            if not params:
                continue
            lr = group["lr"]
            momentum = group["momentum"]
            backend_steps = group["backend_steps"]
            nesterov = group["nesterov"]
            wd = group["weight_decay"]

            total_params = sum(int(p.numel()) for p in params)
            updates_flat = torch.zeros(total_params, device=params[0].device,
                                       dtype=_MUON_DTYPE)

            curr = 0
            for i, p in enumerate(params):
                if i % world_size == rank and p.grad is not None:
                    g = p.grad
                    state = self.state[p]
                    if "momentum_buffer" not in state:
                        state["momentum_buffer"] = torch.zeros_like(g)
                    buf = state["momentum_buffer"]
                    buf.mul_(momentum).add_(g)
                    if nesterov:
                        g = g.add(buf, alpha=momentum)
                    g = zeropower_via_newtonschulz5(g, steps=backend_steps)
                    g = g * max(1, g.size(0) / g.size(1)) ** 0.5
                    updates_flat[curr: curr + p.numel()] = g.reshape(-1)
                curr += p.numel()

            if distributed:
                dist.all_reduce(updates_flat, op=dist.ReduceOp.SUM)

            curr = 0
            for p in params:
                g = updates_flat[curr: curr + p.numel()].view_as(p).to(dtype=p.dtype)
                if wd > 0.0:
                    p.mul_(1.0 - lr * wd)
                p.add_(g, alpha=-lr)
                curr += p.numel()
        return loss


# ----------------------------------------------------------------------------------
# QUANTIZATION PRIMITIVES  (shared by QAT, QA-EMA and the exporter)
# ----------------------------------------------------------------------------------

# The clipping rule is process-global on purpose: QAT, QA-EMA and the exporter must use
# byte-identical lattice geometry, otherwise the "quantization tax" they measure is not
# the tax of the shipped artifact. Set once from `Hyperparameters.quant_clip` in main().
CLIP_MODE = "percentile"
CLIP_PERCENTILE = 99.99984


def symmetric_clip(t: Tensor, bits: int, sdclip_k: float) -> Tensor:
    """Per-output-row clip magnitude.

    `CLIP_MODE == "sdclip"` uses `clip = k * std(row)`, motivated by rate-distortion:
    the number of quantization bins a row deserves should follow its spread, not its
    largest coordinate. `CLIP_MODE == "percentile"` reproduces the scaffold's rule.
    """
    t32 = t.float()
    if t32.ndim == 2:
        if CLIP_MODE == "sdclip":
            return (sdclip_k * t32.std(dim=1, unbiased=False)).clamp_min(1e-12)
        q = torch.quantile(t32.abs(), CLIP_PERCENTILE / 100.0, dim=1)
        return q.clamp_min(1e-12)
    if CLIP_MODE == "sdclip":
        return t32.std(unbiased=False).clamp_min(1e-12)
    return torch.quantile(t32.abs().flatten(), CLIP_PERCENTILE / 100.0).clamp_min(1e-12)


def quant_dequant(t: Tensor, bits: int, sdclip_k: float) -> tuple[Tensor, Tensor]:
    """Symmetric per-row (2D) / per-tensor (1D) quantization. Returns (dequant, scale)."""
    qmax = float((1 << (bits - 1)) - 1)
    t32 = t.float()
    clip = symmetric_clip(t32, bits, sdclip_k)
    scale = clip / qmax
    if t32.ndim == 2:
        q = torch.clamp(torch.round(t32 / scale[:, None]), -qmax, qmax)
        return q * scale[:, None], scale
    q = torch.clamp(torch.round(t32 / scale), -qmax, qmax)
    return q * scale, scale


def fake_quant_ste(w: Tensor, bits: int, sdclip_k: float) -> Tensor:
    """Straight-through estimator wrapper: forward quantized, backward identity."""
    if bits >= 16 or w.ndim < 2:
        return w
    deq, _ = quant_dequant(w, bits, sdclip_k)
    return w + (deq.to(w.dtype) - w).detach()


# ----------------------------------------------------------------------------------
# TOKENIZER-AGNOSTIC EVALUATION SETUP  (verbatim semantics from the official script)
# ----------------------------------------------------------------------------------

def build_sentencepiece_luts(sp: spm.SentencePieceProcessor, vocab_size: int,
                             device: torch.device) -> tuple[Tensor, Tensor, Tensor]:
    sp_vocab_size = int(sp.vocab_size())
    table_size = max(sp_vocab_size, vocab_size)
    base_bytes_np = np.zeros((table_size,), dtype=np.int16)
    has_leading_space_np = np.zeros((table_size,), dtype=np.bool_)
    is_boundary_token_np = np.ones((table_size,), dtype=np.bool_)
    for token_id in range(sp_vocab_size):
        if sp.is_control(token_id) or sp.is_unknown(token_id) or sp.is_unused(token_id):
            continue
        is_boundary_token_np[token_id] = False
        if sp.is_byte(token_id):
            base_bytes_np[token_id] = 1
            continue
        piece = sp.id_to_piece(token_id)
        if piece.startswith("\u2581"):
            has_leading_space_np[token_id] = True
            piece = piece[1:]
        base_bytes_np[token_id] = len(piece.encode("utf-8"))
    return (
        torch.tensor(base_bytes_np, dtype=torch.int16, device=device),
        torch.tensor(has_leading_space_np, dtype=torch.bool, device=device),
        torch.tensor(is_boundary_token_np, dtype=torch.bool, device=device),
    )


def load_data_shard(file: Path) -> Tensor:
    header_bytes = 256 * np.dtype("<i4").itemsize
    token_bytes = np.dtype("<u2").itemsize
    header = np.fromfile(file, dtype="<i4", count=256)
    if header.size != 256 or int(header[0]) != 20240520 or int(header[1]) != 1:
        raise ValueError(f"Unexpected shard header for {file}")
    num_tokens = int(header[2])
    expected_size = header_bytes + num_tokens * token_bytes
    if file.stat().st_size != expected_size:
        raise ValueError(f"Shard size mismatch for {file}: expected {expected_size} bytes")
    tokens_np = np.fromfile(file, dtype="<u2", count=num_tokens, offset=header_bytes)
    if tokens_np.size != num_tokens:
        raise ValueError(f"Short read for {file}")
    return torch.from_numpy(tokens_np.astype(np.uint16, copy=False))


def load_validation_tokens(pattern: str, seq_len: int) -> Tensor:
    files = [Path(p) for p in sorted(glob.glob(pattern))]
    if not files:
        raise FileNotFoundError(f"No files found for pattern: {pattern}")
    tokens = torch.cat([load_data_shard(f) for f in files]).contiguous()
    usable = ((tokens.numel() - 1) // seq_len) * seq_len
    if usable <= 0:
        raise ValueError(f"Validation split is too short for TRAIN_SEQ_LEN={seq_len}")
    return tokens[: usable + 1]


def eval_val(args: Hyperparameters, model: nn.Module, rank: int, world_size: int,
             device: torch.device, grad_accum_steps: int, val_tokens: Tensor,
             base_bytes_lut: Tensor, has_leading_space_lut: Tensor,
             is_boundary_token_lut: Tensor) -> tuple[float, float]:
    local_batch_tokens = max(args.val_batch_size // (world_size * grad_accum_steps), args.train_seq_len)
    local_batch_seqs = local_batch_tokens // args.train_seq_len
    total_seqs = (val_tokens.numel() - 1) // args.train_seq_len
    seq_start = (total_seqs * rank) // world_size
    seq_end = (total_seqs * (rank + 1)) // world_size
    val_loss_sum = torch.zeros((), device=device, dtype=torch.float64)
    val_token_count = torch.zeros((), device=device, dtype=torch.float64)
    val_byte_count = torch.zeros((), device=device, dtype=torch.float64)

    model.eval()
    # NOTE: `no_grad` (not `inference_mode`) is used deliberately. Modules cache
    # derived tensors (RoPE cos/sin tables); tensors created inside `inference_mode`
    # are "inference tensors" and cannot participate in a later autograd graph, which
    # breaks the very first training step when WARMUP_STEPS=0.
    with torch.no_grad():
        for batch_seq_start in range(seq_start, seq_end, local_batch_seqs):
            batch_seq_end = min(batch_seq_start + local_batch_seqs, seq_end)
            raw_start = batch_seq_start * args.train_seq_len
            raw_end = batch_seq_end * args.train_seq_len + 1
            local = val_tokens[raw_start:raw_end].to(device=device, dtype=torch.int64,
                                                     non_blocking=True)
            x = local[:-1].reshape(-1, args.train_seq_len)
            y = local[1:].reshape(-1, args.train_seq_len)
            with autocast_ctx(device):
                batch_loss = model(x, y).detach()
            batch_token_count = float(y.numel())
            val_loss_sum += batch_loss.to(torch.float64) * batch_token_count
            val_token_count += batch_token_count
            prev_ids = x.reshape(-1)
            tgt_ids = y.reshape(-1)
            token_bytes = base_bytes_lut[tgt_ids].to(dtype=torch.int16)
            token_bytes += (has_leading_space_lut[tgt_ids]
                            & ~is_boundary_token_lut[prev_ids]).to(dtype=torch.int16)
            val_byte_count += token_bytes.to(torch.float64).sum()

    if dist.is_available() and dist.is_initialized():
        dist.all_reduce(val_loss_sum, op=dist.ReduceOp.SUM)
        dist.all_reduce(val_token_count, op=dist.ReduceOp.SUM)
        dist.all_reduce(val_byte_count, op=dist.ReduceOp.SUM)

    val_loss = val_loss_sum / val_token_count
    bits_per_token = val_loss.item() / math.log(2.0)
    tokens_per_byte = val_token_count.item() / val_byte_count.item()
    model.train()
    return float(val_loss.item()), float(bits_per_token * tokens_per_byte)


# ----------------------------------------------------------------------------------
# ARTIFACT EXPORT
# ----------------------------------------------------------------------------------

CONTROL_TENSOR_NAME_PATTERNS = tuple(
    p for p in _env(
        "CONTROL_TENSOR_NAME_PATTERNS",
        "attn_scale,attn_scales,mlp_scale,mlp_scales,resid_mix,resid_mixes,q_gain,"
        "skip_weight,skip_weights",
    ).split(",") if p
)

_INT_MAX_BITS = 16  # sentinel: keep floating point


def _should_quantize(name: str, t: Tensor) -> bool:
    """2D float matrices and the tied embedding get packed; scalars/vectors stay fp32."""
    if not t.is_floating_point() or t.ndim < 2:
        return False
    if any(p in name for p in CONTROL_TENSOR_NAME_PATTERNS):
        return False
    return True


def quantize_weight_rtn(t: Tensor, bits: int, sdclip_k: float) -> tuple[Tensor, Tensor]:
    """RTN (+ optional SDClip) codes and scales for a single weight tensor."""
    qmax = (1 << (bits - 1)) - 1
    t32 = t.float()
    clip = symmetric_clip(t32, bits, sdclip_k)
    scale = clip / qmax
    if t32.ndim == 2:
        q = torch.clamp(torch.round(t32 / scale[:, None]), -qmax, qmax)
    else:
        q = torch.clamp(torch.round(t32 / scale), -qmax, qmax)
    return q, scale


def quantize_state_dict(state_dict: dict[str, Tensor], args: Hyperparameters,
                        gptq_result: dict[str, tuple[Tensor, Tensor]] | None = None):
    """Mixed-precision artifact: int6 block matrices, int8 embeddings, fp16 controls.

    `gptq_result` (name -> (codes, scales)) overrides RTN for the tensors it covers.
    """
    quantized, scales, dtypes, passthrough, passthrough_orig = {}, {}, {}, {}, {}
    stats = dict.fromkeys(("param_count", "num_tensors", "baseline_tensor_bytes",
                           "payload_bytes"), 0)
    for name, tensor in state_dict.items():
        t = tensor.detach().to("cpu").contiguous()
        stats["param_count"] += int(t.numel())
        stats["num_tensors"] += 1
        stats["baseline_tensor_bytes"] += int(t.numel()) * int(t.element_size())

        if not t.is_floating_point():
            passthrough[name] = t
            stats["payload_bytes"] += int(t.numel()) * int(t.element_size())
            continue

        if not _should_quantize(name, t):
            # small / control tensors stay exact; fp16 storage keeps metadata cheap
            if any(p in name for p in CONTROL_TENSOR_NAME_PATTERNS):
                kept = t.float().contiguous()
                if t.dtype != torch.float32:
                    passthrough_orig[name] = str(t.dtype).removeprefix("torch.")
            else:
                kept = t.to(torch.float16).contiguous()
            passthrough[name] = kept
            stats["payload_bytes"] += int(kept.numel()) * int(kept.element_size())
            continue

        bits = args.quant_embed_bits if name.endswith("tok_emb.weight") else args.quant_bits
        if gptq_result is not None and name in gptq_result:
            q, scale = gptq_result[name]
        else:
            q, scale = quantize_weight_rtn(t, bits, args.sdclip_k)
        quantized[name] = q.to(torch.int8).contiguous()
        scales[name] = scale.to(torch.float16).contiguous()
        dtypes[name] = str(t.dtype).removeprefix("torch.")
        stats["payload_bytes"] += int(quantized[name].numel())
        stats["payload_bytes"] += int(scales[name].numel()) * 2

    obj = {"__quant_format__": "mixed_int_v1", "bits": args.quant_bits,
           "embed_bits": args.quant_embed_bits, "quantized": quantized,
           "scales": scales, "dtypes": dtypes, "passthrough": passthrough}
    if passthrough_orig:
        obj["passthrough_orig_dtypes"] = passthrough_orig
    return obj, stats


# --- GPTQ (Frantar et al. 2022) on top of SDClip, as used by the leaderboard SOTA ---

class HessianCollector:
    """Accumulates X^T X for every CastedLinear from calibration forward passes."""

    def __init__(self, model: nn.Module):
        self.H: dict[str, Tensor] = {}
        self.count: dict[str, int] = {}
        self.handles = []
        for name, module in model.named_modules():
            if isinstance(module, CastedLinear):
                self.handles.append(module.register_forward_pre_hook(self._make_hook(name)))

    def _make_hook(self, name: str):
        def hook(module, inputs):
            x = inputs[0].detach()
            x = x.reshape(-1, x.size(-1)).float()
            n = x.size(0)
            if n == 0:
                return
            H = x.t() @ x
            if name in self.H:
                self.H[name] += H
                self.count[name] += n
            else:
                self.H[name] = H
                self.count[name] = n
        return hook

    def close(self) -> None:
        for h in self.handles:
            h.remove()
        self.handles = []

    def normalized(self) -> dict[str, Tensor]:
        return {k: (v / max(self.count[k], 1)) for k, v in self.H.items()}


def gptq_quantize(w: Tensor, H: Tensor, bits: int, sdclip_k: float,
                  percdamp: float = 0.01, blocksize: int = 128
                  ) -> tuple[Tensor, Tensor]:
    """Sequential column-wise GPTQ for a single (out, in) weight matrix."""
    W = w.detach().float().clone()
    out_f, in_f = W.shape
    qmax = (1 << (bits - 1)) - 1

    if H.shape[0] != in_f:
        raise ValueError(f"Hessian shape {tuple(H.shape)} incompatible with weight {tuple(W.shape)}")
    H = H.detach().float().clone()
    dead = torch.diag(H) == 0
    H[dead, dead] = 1.0
    W[:, dead] = 0.0
    damp = percdamp * torch.mean(torch.diag(H)).clamp_min(1e-12)
    H[torch.arange(in_f), torch.arange(in_f)] += damp
    try:
        Hinv = torch.cholesky_inverse(torch.linalg.cholesky(H))
        Hinv = torch.linalg.cholesky(Hinv, upper=True)
    except Exception:
        Hinv = torch.eye(in_f)

    # SDClip: one clip magnitude per output row, estimated on the full-precision row.
    clip = symmetric_clip(W, bits, sdclip_k)
    scale = (clip / qmax).clamp_min(1e-12)

    Q = torch.zeros_like(W)
    for i1 in range(0, in_f, blocksize):
        i2 = min(i1 + blocksize, in_f)
        W1 = W[:, i1:i2].clone()
        Q1 = torch.zeros_like(W1)
        Err1 = torch.zeros_like(W1)
        Hinv1 = Hinv[i1:i2, i1:i2]
        for i in range(i2 - i1):
            w_col = W1[:, i]
            d = Hinv1[i, i]
            q = torch.clamp(torch.round(w_col / scale), -qmax, qmax)
            Q1[:, i] = q
            err = (w_col - q * scale) / d
            W1[:, i:] -= err.unsqueeze(1) @ Hinv1[i, i:].unsqueeze(0)
            Err1[:, i] = err
        Q[:, i1:i2] = Q1
    return Q, scale


def gptq_state_dict(model: nn.Module, args: Hyperparameters,
                    calib_batches: list[tuple[Tensor, Tensor]]
                    ) -> tuple[dict[str, tuple[Tensor, Tensor]], dict[str, float]]:
    """Run GPTQ over every CastedLinear in the model using calibration batches."""
    collector = HessianCollector(model)
    was_training = model.training
    model.eval()
    with torch.inference_mode():
        for x, y in calib_batches:
            model(x, y)
    collector.close()
    model.train(was_training)

    Hs = collector.normalized()
    out: dict[str, tuple[Tensor, Tensor]] = {}
    residuals: dict[str, float] = {}
    for name, module in model.named_modules():
        if not isinstance(module, CastedLinear):
            continue
        if name not in Hs:
            continue
        H = Hs[name].to(module.weight.device)
        bits = args.quant_embed_bits if name.endswith("tok_emb.weight") else args.quant_bits
        Q, scale = gptq_quantize(module.weight.data, H, bits, args.sdclip_k)
        ref = module.weight.data.detach().float()
        deq = Q * (scale[:, None] if ref.ndim == 2 else scale)
        residuals[name] = float((ref - deq).pow(2).mean().sqrt().item())
        full_name = f"{name}.weight" if name else ""
        if full_name:
            out[full_name] = (Q, scale)
    return out, residuals


def dequantize_state_dict(obj: dict) -> dict[str, Tensor]:
    out: dict[str, Tensor] = {}
    orig = obj.get("passthrough_orig_dtypes", {})
    for name, q in obj["quantized"].items():
        dtype = getattr(torch, obj["dtypes"][name])
        s = obj["scales"][name].to(torch.float32)
        if s.ndim > 0 and q.ndim > 1:
            out[name] = (q.float() * s.reshape(-1, *([1] * (q.ndim - 1)))).to(dtype).contiguous()
        else:
            out[name] = (q.float() * float(s.reshape(-1)[0])).to(dtype).contiguous()
    for name, t in obj["passthrough"].items():
        t = t.detach().to("cpu").contiguous()
        d = orig.get(name)
        if isinstance(d, str):
            t = t.to(dtype=getattr(torch, d)).contiguous()
        out[name] = t
    return out


def compress_blob(raw: bytes, how: str) -> bytes:
    if how == "brotli" and brotli is not None:
        return brotli.compress(raw, quality=11)
    return zlib.compress(raw, level=9)


def decompress_blob(blob: bytes, how: str) -> bytes:
    if how == "brotli":
        if brotli is None:
            raise RuntimeError("brotli not installed")
        return brotli.decompress(blob)
    return zlib.decompress(blob)


# ----------------------------------------------------------------------------------
# DATA LOADING  (verbatim from the official scaffold)
# ----------------------------------------------------------------------------------

class TokenStream:
    def __init__(self, pattern: str):
        self.files = [Path(p) for p in sorted(glob.glob(pattern))]
        if not self.files:
            raise FileNotFoundError(f"No files found for pattern: {pattern}")
        self.file_idx = 0
        self.tokens = load_data_shard(self.files[0])
        self.pos = 0

    def _advance_file(self) -> None:
        self.file_idx = (self.file_idx + 1) % len(self.files)
        self.tokens = load_data_shard(self.files[self.file_idx])
        self.pos = 0

    def take(self, n: int) -> Tensor:
        chunks: list[Tensor] = []
        remaining = n
        while remaining > 0:
            avail = self.tokens.numel() - self.pos
            if avail <= 0:
                self._advance_file()
                continue
            k = min(remaining, avail)
            chunks.append(self.tokens[self.pos: self.pos + k])
            self.pos += k
            remaining -= k
        return chunks[0] if len(chunks) == 1 else torch.cat(chunks)


class DistributedTokenLoader:
    def __init__(self, pattern: str, rank: int, world_size: int, device: torch.device):
        self.rank, self.world_size, self.device = rank, world_size, device
        self.stream = TokenStream(pattern)

    def next_batch(self, global_tokens: int, seq_len: int,
                   grad_accum_steps: int) -> tuple[Tensor, Tensor]:
        local_tokens = global_tokens // (self.world_size * grad_accum_steps)
        per_rank_span = local_tokens + 1
        chunk = self.stream.take(per_rank_span * self.world_size)
        start = self.rank * per_rank_span
        local = chunk[start: start + per_rank_span].to(dtype=torch.int64)
        x = local[:-1].reshape(-1, seq_len)
        y = local[1:].reshape(-1, seq_len)
        return x.to(self.device, non_blocking=True), y.to(self.device, non_blocking=True)


# ----------------------------------------------------------------------------------
# TRANSFORMER MODULES
# ----------------------------------------------------------------------------------

_DEVICE_TYPE = "cuda"


def autocast_ctx(device: torch.device):
    if device.type == "cuda":
        return torch.autocast(device_type="cuda", dtype=torch.bfloat16, enabled=True)
    return torch.autocast(device_type="cpu", enabled=False)


class RMSNorm(nn.Module):
    def __init__(self, eps: float | None = None):
        super().__init__()
        self.eps = eps

    def forward(self, x: Tensor) -> Tensor:
        return F.rms_norm(x, (x.size(-1),), eps=self.eps)


class CastedLinear(nn.Linear):
    """fp32 master weights, cast at matmul time; optionally QAT faked-quantized."""

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.qat_bits = 0
        self.qat_sdclip_k = 0.0

    def forward(self, x: Tensor) -> Tensor:
        w = self.weight
        if self.qat_bits > 0 and self.training:
            w = fake_quant_ste(w, self.qat_bits, self.qat_sdclip_k)
        bias = self.bias.to(x.dtype) if self.bias is not None else None
        return F.linear(x, w.to(x.dtype), bias)


def restore_low_dim_params_to_fp32(module: nn.Module) -> None:
    with torch.no_grad():
        for name, param in module.named_parameters():
            if (param.ndim < 2 or any(p in name for p in CONTROL_TENSOR_NAME_PATTERNS)) \
                    and param.dtype != torch.float32:
                param.data = param.data.float()


class Rotary(nn.Module):
    def __init__(self, dim: int, base: float = 10000.0):
        super().__init__()
        inv_freq = 1.0 / (base ** (torch.arange(0, dim, 2, dtype=torch.float32) / dim))
        self.register_buffer("inv_freq", inv_freq, persistent=False)
        self._len = 0
        self._cos = None
        self._sin = None

    def forward(self, seq_len: int, device: torch.device, dtype: torch.dtype):
        if self._cos is None or self._len != seq_len or self._cos.device != device:
            t = torch.arange(seq_len, device=device, dtype=self.inv_freq.dtype)
            f = torch.outer(t, self.inv_freq.to(device))
            self._cos, self._sin = f.cos()[None, None], f.sin()[None, None]
            self._len = seq_len
        return self._cos.to(dtype=dtype), self._sin.to(dtype=dtype)


def apply_rotary_emb(x: Tensor, cos: Tensor, sin: Tensor) -> Tensor:
    half = x.size(-1) // 2
    x1, x2 = x[..., :half], x[..., half:]
    return torch.cat((x1 * cos + x2 * sin, x1 * (-sin) + x2 * cos), dim=-1)


class CausalSelfAttention(nn.Module):
    def __init__(self, dim: int, num_heads: int, num_kv_heads: int, rope_base: float,
                 qk_gain_init: float):
        super().__init__()
        if dim % num_heads != 0:
            raise ValueError("model_dim must be divisible by num_heads")
        if num_heads % num_kv_heads != 0:
            raise ValueError("num_heads must be divisible by num_kv_heads")
        self.num_heads, self.num_kv_heads = num_heads, num_kv_heads
        self.head_dim = dim // num_heads
        if self.head_dim % 2 != 0:
            raise ValueError("head_dim must be even for RoPE")
        kv_dim = num_kv_heads * self.head_dim
        self.c_q = CastedLinear(dim, dim, bias=False)
        self.c_k = CastedLinear(dim, kv_dim, bias=False)
        self.c_v = CastedLinear(dim, kv_dim, bias=False)
        self.proj = CastedLinear(dim, dim, bias=False)
        self.proj._zero_init = True
        self.q_gain = nn.Parameter(torch.full((num_heads,), qk_gain_init, dtype=torch.float32))
        self.rotary = Rotary(self.head_dim, base=rope_base)

    def forward(self, x: Tensor) -> Tensor:
        bsz, seqlen, dim = x.shape
        q = self.c_q(x).reshape(bsz, seqlen, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.c_k(x).reshape(bsz, seqlen, self.num_kv_heads, self.head_dim).transpose(1, 2)
        v = self.c_v(x).reshape(bsz, seqlen, self.num_kv_heads, self.head_dim).transpose(1, 2)
        q = F.rms_norm(q, (q.size(-1),))
        k = F.rms_norm(k, (k.size(-1),))
        cos, sin = self.rotary(seqlen, x.device, q.dtype)
        q = apply_rotary_emb(q, cos, sin)
        k = apply_rotary_emb(k, cos, sin)
        q = q * self.q_gain.to(dtype=q.dtype)[None, :, None, None]
        enable_gqa = self.num_kv_heads != self.num_heads
        try:
            y = F.scaled_dot_product_attention(q, k, v, attn_mask=None, is_causal=True,
                                               enable_gqa=enable_gqa)
        except TypeError:  # older torch without enable_gqa
            if enable_gqa:
                rep = self.num_heads // self.num_kv_heads
                k = k.repeat_interleave(rep, dim=1)
                v = v.repeat_interleave(rep, dim=1)
            y = F.scaled_dot_product_attention(q, k, v, attn_mask=None, is_causal=True)
        y = y.transpose(1, 2).contiguous().reshape(bsz, seqlen, dim)
        return self.proj(y)


class MLP(nn.Module):
    def __init__(self, dim: int, mlp_mult: int):
        super().__init__()
        hidden = mlp_mult * dim
        self.fc = CastedLinear(dim, hidden, bias=False)
        self.proj = CastedLinear(hidden, dim, bias=False)
        self.proj._zero_init = True

    def forward(self, x: Tensor) -> Tensor:
        x = torch.relu(self.fc(x))
        return self.proj(x.square())


class Block(nn.Module):
    """Pre-norm block. `parallel=True` switches to GPT-J parallel residual lanes
    (attention and MLP both read the same pre-residual activation)."""

    def __init__(self, dim: int, num_heads: int, num_kv_heads: int, mlp_mult: int,
                 rope_base: float, qk_gain_init: float, parallel: bool):
        super().__init__()
        self.parallel = parallel
        self.attn_norm = RMSNorm()
        self.mlp_norm = RMSNorm()
        self.attn = CausalSelfAttention(dim, num_heads, num_kv_heads, rope_base, qk_gain_init)
        self.mlp = MLP(dim, mlp_mult)
        self.attn_scale = nn.Parameter(torch.ones(dim, dtype=torch.float32))
        self.mlp_scale = nn.Parameter(torch.ones(dim, dtype=torch.float32))
        self.resid_mix = nn.Parameter(torch.stack((torch.ones(dim), torch.zeros(dim))).float())

    def forward(self, x: Tensor, x0: Tensor) -> Tensor:
        mix = self.resid_mix.to(dtype=x.dtype)
        x = mix[0][None, None, :] * x + mix[1][None, None, :] * x0
        if self.parallel:
            a = self.attn(self.attn_norm(x))
            m = self.mlp(self.mlp_norm(x))
            return x + self.attn_scale.to(x.dtype)[None, None, :] * a \
                     + self.mlp_scale.to(x.dtype)[None, None, :] * m
        x = x + self.attn_scale.to(x.dtype)[None, None, :] * self.attn(self.attn_norm(x))
        x = x + self.mlp_scale.to(x.dtype)[None, None, :] * self.mlp(self.mlp_norm(x))
        return x


class GPT(nn.Module):
    def __init__(self, vocab_size: int, num_layers: int, model_dim: int, num_heads: int,
                 num_kv_heads: int, mlp_mult: int, tie_embeddings: bool,
                 tied_embed_init_std: float, logit_softcap: float, rope_base: float,
                 qk_gain_init: float, layer_schedule: list[int] | None = None,
                 parallel_resid_from: int = -1):
        super().__init__()
        if logit_softcap <= 0.0:
            raise ValueError(f"logit_softcap must be positive, got {logit_softcap}")
        self.tie_embeddings = tie_embeddings
        self.tied_embed_init_std = tied_embed_init_std
        self.logit_softcap = logit_softcap
        self.tok_emb = nn.Embedding(vocab_size, model_dim)
        self.schedule = list(layer_schedule) if layer_schedule else list(range(num_layers))
        self.parallel_resid_from = parallel_resid_from
        n_sched = len(self.schedule)
        self.num_encoder_layers = n_sched // 2
        self.num_decoder_layers = n_sched - self.num_encoder_layers
        self.num_skip_weights = min(self.num_encoder_layers, self.num_decoder_layers)
        self.skip_weights = nn.Parameter(torch.ones(self.num_skip_weights, model_dim,
                                                    dtype=torch.float32))
        self.blocks = nn.ModuleList([
            Block(model_dim, num_heads, num_kv_heads, mlp_mult, rope_base, qk_gain_init,
                  parallel=(parallel_resid_from >= 0 and i >= parallel_resid_from))
            for i in range(num_layers)
        ])
        self.final_norm = RMSNorm()
        self.lm_head = None if tie_embeddings else CastedLinear(model_dim, vocab_size, bias=False)
        if self.lm_head is not None:
            self.lm_head._zero_init = True
        self._init_weights()

    def _init_weights(self) -> None:
        if self.tie_embeddings:
            nn.init.normal_(self.tok_emb.weight, mean=0.0, std=self.tied_embed_init_std)
        for module in self.modules():
            if isinstance(module, nn.Linear) and getattr(module, "_zero_init", False):
                nn.init.zeros_(module.weight)

    def forward(self, input_ids: Tensor, target_ids: Tensor) -> Tensor:
        x = self.tok_emb(input_ids)
        x = F.rms_norm(x, (x.size(-1),))
        x0 = x
        skips: list[Tensor] = []
        for pos, layer_idx in enumerate(self.schedule):
            if pos >= self.num_encoder_layers and skips:
                x = x + self.skip_weights[pos - self.num_encoder_layers].to(x.dtype)[None, None, :] * skips.pop()
            x = self.blocks[layer_idx](x, x0)
            if pos < self.num_encoder_layers:
                skips.append(x)

        x = self.final_norm(x).reshape(-1, x.size(-1))
        targets = target_ids.reshape(-1)
        if self.tie_embeddings:
            logits_proj = F.linear(x, self.tok_emb.weight)
        else:
            if self.lm_head is None:
                raise RuntimeError("lm_head is required when tie_embeddings=False")
            logits_proj = self.lm_head(x)
        logits = self.logit_softcap * torch.tanh(logits_proj / self.logit_softcap)
        return F.cross_entropy(logits.float(), targets, reduction="mean")

    # --- helper hooks -----------------------------------------------------------------
    def set_qat(self, bits: int, embed_bits: int, sdclip_k: float) -> None:
        for name, m in self.named_modules():
            if isinstance(m, CastedLinear):
                m.qat_bits = bits
                m.qat_sdclip_k = sdclip_k
        self._qat_embed = (bits, embed_bits, sdclip_k)

    def clear_qat(self) -> None:
        for m in self.modules():
            if isinstance(m, CastedLinear):
                m.qat_bits = 0
        self._qat_embed = None


# ----------------------------------------------------------------------------------
# EMA / QA-EMA
# ----------------------------------------------------------------------------------

class WeightAverager:
    """Exponential moving average of the trainable parameters.

    `quant_aware=True` averages *dequantized copies* of the parameters on the
    deployed quantization lattice instead of the raw fp32 weights. The averaged
    model is then already near a representable point, which shrinks the
    post-quantization degradation ("quantization tax"). This is the submission's
    original component; see the technical report Sec. 3.4.
    """

    def __init__(self, model: nn.Module, decay: float, quant_aware: bool,
                 bits: int, embed_bits: int, sdclip_k: float):
        self.decay = decay
        self.quant_aware = quant_aware
        self.bits = bits
        self.embed_bits = embed_bits
        self.sdclip_k = sdclip_k
        self.shadow: dict[str, Tensor] = {}
        self.n_updates = 0

    @torch.no_grad()
    def update(self, model: nn.Module) -> None:
        for name, p in model.named_parameters():
            if not p.requires_grad:
                continue
            src = p.detach()
            if self.quant_aware and src.ndim >= 2:
                bits = self.embed_bits if name.endswith("tok_emb.weight") else self.bits
                src = quant_dequant(src, bits, self.sdclip_k)[0]
            if name not in self.shadow:
                self.shadow[name] = src.clone()
            else:
                self.shadow[name].mul_(self.decay).add_(src, alpha=1.0 - self.decay)
        self.n_updates += 1

    @torch.no_grad()
    def copy_to(self, model: nn.Module) -> None:
        for name, p in model.named_parameters():
            if name in self.shadow:
                p.data.copy_(self.shadow[name].to(p.dtype))


# ----------------------------------------------------------------------------------
# TRAINING
# ----------------------------------------------------------------------------------

def main() -> None:
    global _MUON_DTYPE, _DEVICE_TYPE, CLIP_MODE, CLIP_PERCENTILE

    code = Path(__file__).read_text(encoding="utf-8")
    args = Hyperparameters()
    CLIP_MODE = args.quant_clip
    CLIP_PERCENTILE = args.clip_percentile
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # ----------------------------- runtime setup -----------------------------
    if args.device_pref == "cpu":
        use_cuda = False
    elif args.device_pref == "cuda":
        use_cuda = torch.cuda.is_available()
        if not use_cuda:
            raise RuntimeError("DEVICE=cuda requested but CUDA is unavailable")
    else:
        use_cuda = torch.cuda.is_available()
    if args.threads > 0:
        torch.set_num_threads(args.threads)

    distributed = "RANK" in os.environ and "WORLD_SIZE" in os.environ and use_cuda
    rank = int(os.environ.get("RANK", "0"))
    world_size = int(os.environ.get("WORLD_SIZE", "1"))
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    if world_size <= 0:
        raise ValueError(f"WORLD_SIZE must be positive, got {world_size}")
    grad_accum_steps = max(1, 8 // world_size) if use_cuda else 1
    grad_scale = 1.0 / grad_accum_steps

    if use_cuda:
        device = torch.device("cuda", local_rank)
        torch.cuda.set_device(device)
        _MUON_DTYPE = torch.bfloat16
        _DEVICE_TYPE = "cuda"
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
        try:
            from torch.backends.cuda import (enable_cudnn_sdp, enable_flash_sdp,
                                             enable_math_sdp, enable_mem_efficient_sdp)
            enable_cudnn_sdp(False)
            enable_flash_sdp(True)
            enable_mem_efficient_sdp(False)
            enable_math_sdp(False)
        except Exception:
            pass
        if distributed:
            dist.init_process_group(backend="nccl", device_id=device)
            dist.barrier()
    else:
        device = torch.device("cpu")
        _MUON_DTYPE = torch.float32
        _DEVICE_TYPE = "cpu"

    master_process = rank == 0
    logfile = None
    if master_process:
        (out_dir / "logs").mkdir(parents=True, exist_ok=True)
        logfile = out_dir / "logs" / f"{args.run_id}.txt"
        logfile.write_text("", encoding="utf-8")

    def log0(msg: str, console: bool = True) -> None:
        if not master_process:
            return
        if console:
            print(msg, flush=True)
        if logfile is not None:
            with open(logfile, "a", encoding="utf-8") as f:
                print(msg, file=f)

    log0(code, console=False)
    log0("=" * 100, console=False)
    log0(f"Running Python {sys.version}", console=False)
    log0(f"Running PyTorch {torch.__version__}", console=False)
    if use_cuda:
        log0(subprocess.run(["nvidia-smi"], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            text=True, check=False).stdout, console=False)
    else:
        log0(f"device:cpu torch_threads:{torch.get_num_threads()}", console=False)
    log0("=" * 100, console=False)

    # ----------------------------- export-rule sanity -----------------------
    # `quant_method` names the algorithm (RTN vs GPTQ); `quant_clip` names the clip rule.
    # They are independent knobs. "rtn_sdclip" was a legacy value whose *name* implied
    # SDClip without ever selecting it -- SDClip is enabled by QUANT_CLIP=sdclip alone.
    # Normalise it and say so out loud, so that no log or manifest keeps propagating a
    # label that contradicts the rule actually in force.
    if args.quant_method == "rtn_sdclip":
        log0("WARNING: QUANT_METHOD=rtn_sdclip is a legacy alias for 'rtn'. "
             "SDClip is selected by QUANT_CLIP=sdclip, not by the method name. "
             "Normalising to method=rtn.")
        args.quant_method = "rtn"
    log0(f"export rule: method={args.quant_method} clip={args.quant_clip} "
         f"bits={args.quant_bits} embed_bits={args.quant_embed_bits} "
         f"compress={args.compress}")

    # ----------------------------- tokenizer --------------------------------
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if use_cuda:
        torch.cuda.manual_seed_all(args.seed)

    if not args.tokenizer_path.endswith(".model"):
        raise ValueError(f"Script only setup for SentencePiece .model file: {args.tokenizer_path}")
    sp = spm.SentencePieceProcessor(model_file=args.tokenizer_path)
    if int(sp.vocab_size()) != args.vocab_size:
        raise ValueError(f"VOCAB_SIZE={args.vocab_size} != tokenizer vocab={int(sp.vocab_size())}")
    dataset_dir = Path(args.data_path).resolve()
    n_train_files = len(list(dataset_dir.glob("fineweb_train_*.bin")))
    val_tokens = load_validation_tokens(args.val_files, args.train_seq_len)
    base_bytes_lut, has_leading_space_lut, is_boundary_token_lut = build_sentencepiece_luts(
        sp, args.vocab_size, device)
    log0(f"val_bpb:enabled tokenizer_kind=sentencepiece tokenizer_path={args.tokenizer_path}")
    log0(f"train_loader:dataset:{dataset_dir.name} train_shards:{n_train_files}")
    log0(f"val_loader:tokens:{val_tokens.numel() - 1}")

    # ----------------------------- model ------------------------------------
    schedule = [int(x) for x in args.layer_schedule.split(",") if x.strip()] or None
    base_model = GPT(
        vocab_size=args.vocab_size, num_layers=args.num_layers, model_dim=args.model_dim,
        num_heads=args.num_heads, num_kv_heads=args.num_kv_heads, mlp_mult=args.mlp_mult,
        tie_embeddings=args.tie_embeddings, tied_embed_init_std=args.tied_embed_init_std,
        logit_softcap=args.logit_softcap, rope_base=args.rope_base,
        qk_gain_init=args.qk_gain_init, layer_schedule=schedule,
        parallel_resid_from=args.parallel_resid_from,
    ).to(device)
    if use_cuda:
        base_model = base_model.bfloat16()
    for module in base_model.modules():
        if isinstance(module, CastedLinear):
            module.float()
    restore_low_dim_params_to_fp32(base_model)

    compiled_model = base_model
    if args.compile_model and use_cuda:
        compiled_model = torch.compile(base_model, dynamic=False, fullgraph=True)
    model: nn.Module = DDP(compiled_model, device_ids=[local_rank], broadcast_buffers=False) \
        if distributed else compiled_model

    block_named = list(base_model.blocks.named_parameters())
    matrix_params = [p for name, p in block_named if p.ndim == 2
                     and not any(q in name for q in CONTROL_TENSOR_NAME_PATTERNS)]
    scalar_params = [p for name, p in block_named if p.ndim < 2
                     or any(q in name for q in CONTROL_TENSOR_NAME_PATTERNS)]
    if base_model.skip_weights.numel() > 0:
        scalar_params.append(base_model.skip_weights)
    token_lr = args.tied_embed_lr if args.tie_embeddings else args.embed_lr
    fused = use_cuda
    optimizer_tok = torch.optim.Adam(
        [{"params": [base_model.tok_emb.weight], "lr": token_lr, "base_lr": token_lr}],
        betas=(args.beta1, args.beta2), eps=args.adam_eps, fused=fused)
    optimizer_muon = Muon(matrix_params, lr=args.matrix_lr, momentum=args.muon_momentum,
                          backend_steps=args.muon_backend_steps, weight_decay=args.weight_decay)
    for g in optimizer_muon.param_groups:
        g["base_lr"] = args.matrix_lr
    optimizer_scalar = torch.optim.Adam(
        [{"params": scalar_params, "lr": args.scalar_lr, "base_lr": args.scalar_lr}],
        betas=(args.beta1, args.beta2), eps=args.adam_eps, fused=fused)
    optimizers: list[torch.optim.Optimizer] = [optimizer_tok, optimizer_muon, optimizer_scalar]
    if base_model.lm_head is not None:
        optimizers.insert(1, torch.optim.Adam(
            [{"params": [base_model.lm_head.weight], "lr": args.head_lr, "base_lr": args.head_lr}],
            betas=(args.beta1, args.beta2), eps=args.adam_eps, fused=fused))

    n_params = sum(p.numel() for p in base_model.parameters())
    log0(f"model_params:{n_params}")
    log0(f"schema:layers={args.num_layers} dim={args.model_dim} heads={args.num_heads} "
         f"kv_heads={args.num_kv_heads} mlp_mult={args.mlp_mult} vocab={args.vocab_size}")
    log0(f"schedule:{base_model.schedule} parallel_resid_from:{args.parallel_resid_from}")
    log0(f"components:qk_gain={args.qk_gain_init} ema={args.ema_decay} "
         f"qa_ema={int(args.ema_quant_aware)} qat_frac={args.qat_start_frac} "
         f"quant={args.quant_method}/{args.quant_clip}/int{args.quant_bits}"
         f"/emb{args.quant_embed_bits} sdclip_k={args.sdclip_k} "
         f"compress={args.compress} wd={args.weight_decay}")
    log0(f"world_size:{world_size} grad_accum_steps:{grad_accum_steps} device:{device.type}")
    log0(f"train_batch_tokens:{args.train_batch_tokens} train_seq_len:{args.train_seq_len} "
         f"iterations:{args.iterations} max_wallclock_seconds:{args.max_wallclock_seconds:.3f}")
    log0(f"seed:{args.seed}")

    train_loader = DistributedTokenLoader(args.train_files, rank, world_size, device)

    def zero_grad_all() -> None:
        for opt in optimizers:
            opt.zero_grad(set_to_none=True)

    max_wallclock_ms = 1000.0 * args.max_wallclock_seconds if args.max_wallclock_seconds > 0 else None
    warmdown_iters = args.warmdown_iters
    if args.warmdown_frac > 0:
        warmdown_iters = max(1, int(args.iterations * args.warmdown_frac))

    def lr_mul(step: int, elapsed_ms: float) -> float:
        if warmdown_iters <= 0:
            return 1.0
        if max_wallclock_ms is None:
            start = max(args.iterations - warmdown_iters, 0)
            if start <= step < args.iterations:
                return max((args.iterations - step) / max(warmdown_iters, 1), 0.0)
            return 1.0
        step_ms = elapsed_ms / max(step, 1)
        warmdown_ms = warmdown_iters * step_ms
        remaining = max(max_wallclock_ms - elapsed_ms, 0.0)
        return remaining / max(warmdown_ms, 1e-9) if remaining <= warmdown_ms else 1.0

    averager = None
    if args.ema_decay > 0:
        averager = WeightAverager(base_model, args.ema_decay, args.ema_quant_aware,
                                  args.quant_bits, args.quant_embed_bits, args.sdclip_k)
    ema_start_step = int(args.ema_start_frac * args.iterations) if args.ema_start_frac >= 0 \
        else max(1, args.iterations - warmdown_iters)

    if args.warmup_steps > 0:
        init_state = {k: v.detach().cpu().clone() for k, v in base_model.state_dict().items()}
        init_opt = [copy.deepcopy(o.state_dict()) for o in optimizers]
        model.train()
        for ws in range(args.warmup_steps):
            zero_grad_all()
            for _ in range(grad_accum_steps):
                x, y = train_loader.next_batch(args.train_batch_tokens, args.train_seq_len,
                                               grad_accum_steps)
                with autocast_ctx(device):
                    wl = model(x, y)
                (wl * grad_scale).backward()
            for o in optimizers:
                o.step()
            zero_grad_all()
        base_model.load_state_dict(init_state, strict=True)
        for o, s in zip(optimizers, init_opt, strict=True):
            o.load_state_dict(s)
        zero_grad_all()
        train_loader = DistributedTokenLoader(args.train_files, rank, world_size, device)

    # ----------------------------- main loop ---------------------------------
    training_time_ms = 0.0
    stop_after_step: int | None = None
    qat_on = False
    if use_cuda:
        torch.cuda.synchronize()
    t0 = time.perf_counter()
    step = 0
    train_loss = torch.zeros((), device=device)
    history: list[dict] = []

    while True:
        last_step = step == args.iterations or (stop_after_step is not None and step >= stop_after_step)
        should_validate = last_step or (args.val_loss_every > 0 and step % args.val_loss_every == 0)
        if should_validate:
            if use_cuda:
                torch.cuda.synchronize()
            training_time_ms += 1000.0 * (time.perf_counter() - t0)
            eval_model = base_model
            if averager is not None and averager.n_updates > 0:
                raw_backup = {k: v.detach().clone() for k, v in base_model.state_dict().items()}
                averager.copy_to(base_model)
                val_loss, val_bpb = eval_val(args, eval_model, rank, world_size, device,
                                             grad_accum_steps, val_tokens, base_bytes_lut,
                                             has_leading_space_lut, is_boundary_token_lut)
                base_model.load_state_dict(raw_backup, strict=True)
            else:
                val_loss, val_bpb = eval_val(args, eval_model, rank, world_size, device,
                                             grad_accum_steps, val_tokens, base_bytes_lut,
                                             has_leading_space_lut, is_boundary_token_lut)
            log0(f"step:{step}/{args.iterations} val_loss:{val_loss:.4f} val_bpb:{val_bpb:.4f} "
                 f"train_time:{training_time_ms:.0f}ms step_avg:{training_time_ms / max(step, 1):.2f}ms")
            history.append({"step": step, "val_loss": val_loss, "val_bpb": val_bpb,
                            "train_time_ms": training_time_ms})
            if use_cuda:
                torch.cuda.synchronize()
            t0 = time.perf_counter()

        if last_step:
            if stop_after_step is not None and step < args.iterations:
                log0(f"stopping_early: wallclock_cap train_time:{training_time_ms:.0f}ms "
                     f"step:{step}/{args.iterations}")
            break

        # --- QAT onset (warmdown-aligned when QAT_START_FRAC < 0) ---
        if args.qat_start_frac != 0.0 and not qat_on:
            onset = (-warmdown_iters / args.iterations) if args.qat_start_frac < 0 else args.qat_start_frac
            if step >= max(1, int(onset * args.iterations)):
                base_model.set_qat(args.qat_bits, args.qat_embed_bits, args.sdclip_k)
                qat_on = True
                if averager is not None:
                    averager.shadow.clear()
                log0(f"step:{step} qat_onset:1 bits:{args.qat_bits} embed_bits:{args.qat_embed_bits}")

        elapsed_ms = training_time_ms + 1000.0 * (time.perf_counter() - t0)
        scale = lr_mul(step, elapsed_ms)
        zero_grad_all()
        train_loss = torch.zeros((), device=device)
        for _ in range(grad_accum_steps):
            x, y = train_loader.next_batch(args.train_batch_tokens, args.train_seq_len,
                                           grad_accum_steps)
            with autocast_ctx(device):
                loss = model(x, y)
            train_loss = train_loss + loss.detach()
            (loss * grad_scale).backward()
        train_loss = train_loss / grad_accum_steps

        frac = min(step / args.muon_momentum_warmup_steps, 1.0) if args.muon_momentum_warmup_steps > 0 else 1.0
        mm = (1 - frac) * args.muon_momentum_warmup_start + frac * args.muon_momentum
        for g in optimizer_muon.param_groups:
            g["momentum"] = mm

        for o in optimizers:
            for g in o.param_groups:
                g["lr"] = g["base_lr"] * scale

        if args.grad_clip_norm > 0:
            torch.nn.utils.clip_grad_norm_(base_model.parameters(), args.grad_clip_norm)
        for o in optimizers:
            o.step()
        zero_grad_all()

        if averager is not None and step >= ema_start_step and step % args.ema_every == 0:
            averager.update(base_model)

        step += 1
        approx_ms = training_time_ms + 1000.0 * (time.perf_counter() - t0)
        if args.train_log_every > 0 and (step <= 10 or step % args.train_log_every == 0
                                         or stop_after_step is not None):
            log0(f"step:{step}/{args.iterations} train_loss:{train_loss.item():.4f} "
                 f"train_time:{approx_ms:.0f}ms step_avg:{approx_ms / step:.2f}ms")

        reached_cap = max_wallclock_ms is not None and approx_ms >= max_wallclock_ms
        if distributed and max_wallclock_ms is not None:
            t = torch.tensor(int(reached_cap), device=device)
            dist.all_reduce(t, op=dist.ReduceOp.MAX)
            reached_cap = bool(t.item())
        if stop_after_step is None and reached_cap:
            stop_after_step = step

    if use_cuda:
        log0(f"peak memory allocated: {torch.cuda.max_memory_allocated() // 1024 // 1024} MiB "
             f"reserved: {torch.cuda.max_memory_reserved() // 1024 // 1024} MiB")

    # ----------------------------- export ------------------------------------
    pre_quant_bpb = None
    deployed_pre_bpb = None
    if master_process:
        base_model.clear_qat()
        pre_val_loss, pre_quant_bpb = eval_val(args, base_model, rank, world_size, device,
                                               grad_accum_steps, val_tokens, base_bytes_lut,
                                               has_leading_space_lut, is_boundary_token_lut)
        log0(f"pre_quant val_loss:{pre_val_loss:.4f} val_bpb:{pre_quant_bpb:.4f}")

        # `deployed_pre_bpb` is the pre-quantization BPB of the *weights that will
        # actually be exported*. When EMA is active that is the averaged model, not the
        # raw final step. Without this distinction the "quantization tax" would silently
        # absorb the EMA gain and overstate the cost of compression.
        deployed_pre_bpb = pre_quant_bpb
        if averager is not None and averager.n_updates > 0:
            averager.copy_to(base_model)
            ema_val_loss, ema_bpb = eval_val(args, base_model, rank, world_size, device,
                                             grad_accum_steps, val_tokens, base_bytes_lut,
                                             has_leading_space_lut, is_boundary_token_lut)
            log0(f"ema_pre_quant val_loss:{ema_val_loss:.4f} val_bpb:{ema_bpb:.4f} "
                 f"ema_updates:{averager.n_updates}")
            deployed_pre_bpb = ema_bpb

        state = {k: v.detach().cpu() for k, v in base_model.state_dict().items()}
        torch.save(state, out_dir / "final_model.pt")
        model_bytes = (out_dir / "final_model.pt").stat().st_size
        code_bytes = len(code.encode("utf-8"))
        log0(f"Serialized model: {model_bytes} bytes")
        log0(f"Code size: {code_bytes} bytes")

        gptq_result = None
        if args.quant_method == "gptq":
            # Calibration uses TRAINING shards only. Using the validation split here
            # would violate the challenge rule against touching val data during
            # training/compression, even though the tokens are never used as labels.
            calib_loader = DistributedTokenLoader(args.train_files, rank, world_size, device)
            calib = [calib_loader.next_batch(args.train_batch_tokens, args.train_seq_len, 1)
                     for _ in range(max(1, args.gptq_calib_batches))]
            t_g = time.perf_counter()
            gptq_result, residuals = gptq_state_dict(base_model, args, calib)
            log0(f"gptq_calibration: batches={len(calib)} layers={len(gptq_result)} "
                 f"time={time.perf_counter() - t_g:.1f}s")
            if residuals:
                rmse = " ".join(f"{k}={v:.5f}" for k, v in list(residuals.items())[:6])
                log0(f"gptq_weight_rmse(first6): {rmse}")

        quant_obj, quant_stats = quantize_state_dict(state, args, gptq_result)
        log0(f"quantization: method={args.quant_method} bits={args.quant_bits} "
             f"embed_bits={args.quant_embed_bits} sdclip_k={args.sdclip_k}")
        buf = io.BytesIO()
        torch.save(quant_obj, buf)
        raw = buf.getvalue()
        blob = compress_blob(raw, args.compress)
        (out_dir / "final_model.quant.bin").write_bytes(blob)
        ratio = quant_stats["baseline_tensor_bytes"] / max(quant_stats["payload_bytes"], 1)
        log0(f"Serialized model {args.quant_method}+{args.compress}: {len(blob)} bytes "
             f"(payload:{quant_stats['payload_bytes']} raw_torch:{len(raw)} ratio:{ratio:.2f}x)")
        log0(f"Total submission size: {len(blob) + code_bytes} bytes")

        # roundtrip validation
        loaded = torch.load(io.BytesIO(decompress_blob(blob, args.compress)), map_location="cpu",
                            weights_only=False)
        base_model.load_state_dict(dequantize_state_dict(loaded), strict=True)
        if use_cuda:
            torch.cuda.synchronize()
        t_q = time.perf_counter()
        q_val_loss, q_val_bpb = eval_val(args, base_model, rank, world_size, device,
                                         grad_accum_steps, val_tokens, base_bytes_lut,
                                         has_leading_space_lut, is_boundary_token_lut)
        log0(f"final_quant_roundtrip val_loss:{q_val_loss:.4f} val_bpb:{q_val_bpb:.4f} "
             f"eval_time:{1000.0 * (time.perf_counter() - t_q):.0f}ms")
        log0(f"final_quant_roundtrip_exact val_loss:{q_val_loss:.8f} val_bpb:{q_val_bpb:.8f}")

        if args.result_json:
            Path(args.result_json).write_text(json.dumps({
                "run_id": args.run_id, "seed": args.seed,
                "config": {k: getattr(args, k) for k in dir(args) if not k.startswith("_")
                           and not callable(getattr(args, k))},
                "n_params": n_params,
                "steps_completed": step,
                "train_tokens_seen": step * args.train_batch_tokens,
                "pre_quant_bpb": pre_quant_bpb,
                "deployed_pre_quant_bpb": deployed_pre_bpb,
                "final_bpb": q_val_bpb,
                "final_loss": q_val_loss,
                "artifact_bytes": len(blob),
                "code_bytes": code_bytes,
                "total_bytes": len(blob) + code_bytes,
                "history": history,
                "wallclock_s": training_time_ms / 1000.0,
            }, indent=2, default=str), encoding="utf-8")

    if distributed:
        dist.destroy_process_group()


if __name__ == "__main__":
    main()
